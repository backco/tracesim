**INS2018**

**General introduction**

This dataset contains 15 large synthetic event logs and the corresponding models in petri nets. The data was generated using [PLG2](http://plg.processmining.it/).  
The dataset was originally generated for the experiments in the paper *"Recomposing Conformance: Closing the Circle on Decomposed Alignment-Based Conformance Checking in Process Mining"* published in Information Sciences. 

**Description of the data in this dataset**

The models ranges from 101 to 230 activities, and there are three event logs for each model. Each event log has 1000 cases and can be either perfectly fitting with the model, or containing missing or swapping noise. We refer interested readers to the paper for more details on the data generation procedure.
